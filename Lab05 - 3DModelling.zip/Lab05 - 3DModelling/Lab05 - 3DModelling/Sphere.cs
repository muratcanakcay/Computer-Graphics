﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Lab05___3DModelling;

public class Sphere : Model
{
    public Sphere(int m, int n, int r)
    {
        M = m;
        N = n;
        Radius = r;
        Vertices = new List<Point3d>() { }; 
    }

    public void CalculateVertices()
    {
        //0        - north pole
        //1..mn    - sides
        //mn+1     - south pole

        // north pole
        Vertices.Add(new Point3d //t0
        {
            Global = new Point4(0, Radius, 0, 1),
            Normal = new Point4(0, 1, 0, 0),
            TextureMap = new Point(0.5, 1)
        });

        // sides

        for (var i = 0; i < N; i++)
        {
            for (var j = 0; j < M; j++)
            {
                var xdivR = Math.Cos(2*Math.PI*j/M)*Math.Sin(Math.PI*(i + 1)/(N + 1));
                var ydivR = Math.Cos(Math.PI*(i + 1)/(N + 1));
                var zdivR = Math.Sin(2*Math.PI*j/M)*Math.Sin(Math.PI*(i + 1)/(N + 1));
                double w = 1;

                Vertices.Add(new Point3d //t0
                {
                    Global = new Point4(Radius*xdivR, Radius*ydivR, Radius*zdivR, 1),
                    Normal = new Point4(xdivR, ydivR, zdivR, 0),
                    TextureMap = new Point(j/(M-1d), 1 - (i+1)/(N+1d))
                });
            }
        }

        // south pole
        Vertices.Add(new Point3d //t0
        {
            Global = new Point4(0, -Radius, 0, 1),
            Normal = new Point4(0, -1, 0, 0),
            TextureMap = new Point(0.5, 0)
        });
    }

    public override void Draw(WriteableBitmap wbm, WriteableBitmap texture)
    {
        var drawingData = new List<Pixel>();
        
        // Sphere Top Lid
        for (var i = 0; i < M - 1; i++)
        {
            var topLidTriangle = new Triangle(Vertices[0], Vertices[i+2], Vertices[i+1]);
            if (topLidTriangle.IsFacingCamera())
            {
                topLidTriangle.Fill(drawingData, texture);
                topLidTriangle.Draw(drawingData);
            }
        }

        // Sphere Top Lid last triangle
        var lastTopLidTriangle = new Triangle(Vertices[0],
                                            Vertices[1],
                                            new Point3d
                                            {
                                                Projected = Vertices[M].Projected,
                                                Global = Vertices[M].Global,
                                                Normal = Vertices[M].Normal,
                                                TextureMap = new Point(1, 0)
                                            });
        
        if (lastTopLidTriangle.IsFacingCamera())
        {
            lastTopLidTriangle.Fill(drawingData, texture);
            lastTopLidTriangle.Draw(drawingData);
        }

        // Sphere Bottom Lid
        for (var i = 0; i < M - 1; i++)
        {
            var bottomLidTriangle = new Triangle(Vertices[M*N + 1], Vertices[(N-1)*M + i + 1], Vertices[(N-1)*M + i + 2]);
            if (bottomLidTriangle.IsFacingCamera())
            {
                bottomLidTriangle.Fill(drawingData, texture);
                bottomLidTriangle.Draw(drawingData);
            }
        }

        // Sphere Bottom Lid last triangle
        var lastBottomLidTriangle = new Triangle(Vertices[M*N + 1], Vertices[M*N], Vertices[(N-1)*M + 1]);
        if (lastBottomLidTriangle.IsFacingCamera())
        {
            lastTopLidTriangle.Fill(drawingData, texture);
            lastBottomLidTriangle.Draw(drawingData);
        }

        // Rings making up the strips
        for (var i = 0; i < N - 1; i++)
        {
            // upper strip triangles
            for (var j = 1; j < M; j++)
            {
                var upperStripTriangle = new Triangle(Vertices[i*M + j], Vertices[i*M + j + 1], Vertices[(i+1)*M + j + 1]);
                if (upperStripTriangle.IsFacingCamera())
                {
                    upperStripTriangle.Fill(drawingData, texture);
                    upperStripTriangle.Draw(drawingData);
                }
            }

            // last upper strip triangle
            var lastUpperStripTriangle = new Triangle(Vertices[(i+1)*M], Vertices[i*M + 1], Vertices[(i+1)*M + 1]);
            if (lastUpperStripTriangle.IsFacingCamera())
            {
                lastUpperStripTriangle.Fill(drawingData, texture);
                lastUpperStripTriangle.Draw(drawingData);
            }

            // lower strip triangles
            for (var j = 1; j < M; j++)
            {
                var lowerStripTriangle = new Triangle(Vertices[(i*M) + j], Vertices[(i+1)*M + j + 1], Vertices[(i+1)*M + j]);
                if (lowerStripTriangle.IsFacingCamera())
                {
                    lowerStripTriangle.Fill(drawingData, texture);
                    lowerStripTriangle.Draw(drawingData);
                }
            }

            // last lower strip triangle
            var lastLowerStripTriangle = new Triangle(Vertices[(i+1)*M], Vertices[(i+1)*M + 1], Vertices[(i+2)*M]);
            if (lastLowerStripTriangle.IsFacingCamera())
            {
                lastLowerStripTriangle.Fill(drawingData, texture);
                lastLowerStripTriangle.Draw(drawingData);
            }
        }

        wbm.SetPixels(drawingData);
        drawingData.Clear();
    }
}